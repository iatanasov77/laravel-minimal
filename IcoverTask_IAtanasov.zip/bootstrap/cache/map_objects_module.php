<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MapObjects\\Providers\\MapObjectsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MapObjects\\Providers\\MapObjectsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);