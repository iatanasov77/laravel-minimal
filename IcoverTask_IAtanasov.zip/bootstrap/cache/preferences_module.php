<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Preferences\\Providers\\PreferencesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Preferences\\Providers\\PreferencesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);