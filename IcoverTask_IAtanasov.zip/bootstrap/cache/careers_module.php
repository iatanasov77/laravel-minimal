<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Careers\\Providers\\CareersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Careers\\Providers\\CareersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);