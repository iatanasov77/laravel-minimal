<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CMS\\Providers\\CmsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CMS\\Providers\\CmsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);