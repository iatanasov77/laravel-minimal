<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Franchise\\Providers\\FranchiseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Franchise\\Providers\\FranchiseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);