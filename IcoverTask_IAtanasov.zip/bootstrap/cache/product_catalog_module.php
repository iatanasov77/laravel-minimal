<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProductCatalog\\Providers\\ProductCatalogServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProductCatalog\\Providers\\ProductCatalogServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);