<?php return array (
  'providers' => 
  array (
    0 => 'Icover\\Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Icover\\Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);