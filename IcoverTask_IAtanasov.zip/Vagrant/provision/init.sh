#!/bin/bash

mkdir -p /etc/puppetlabs/facter/facts.d
