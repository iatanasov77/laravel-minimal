<?php namespace Icover\Core\Model\Interfaces;

interface ActivatableAwareInterface
{

    public function activate();

    public function deactivate();
}
