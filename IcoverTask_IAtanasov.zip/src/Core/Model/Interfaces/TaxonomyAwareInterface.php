<?php namespace Icover\Core\Model\Interfaces;

interface TaxonomyAwareInterface
{
    public function addTerm( $term_id );
}
