<?php namespace Icover\Core\Model\Interfaces;

interface TranslateAwareInterface
{
    public function translate( $locale );
}
