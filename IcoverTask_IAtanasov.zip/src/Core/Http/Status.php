<?php namespace Icover\Core\Http;

class Status
{
    const SUCCESS   = 0;

    const ERROR     = 1;
}
